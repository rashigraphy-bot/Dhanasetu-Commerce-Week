# DHANASETU Commerce Week 2026–27

Official event website for DHANASETU – Commerce Week 2026–27 at MIT Arts, Commerce & Science College, Alandi.

## Files
- `index.html` — website structure
- `style.css` — responsive design
- `script.js` — navigation and countdown
- `images/poster.jpg` — event poster
- `images/qr.png` — registration QR crop

## Hosting
This site is a static HTML/CSS/JavaScript website and can be hosted free using GitHub Pages.

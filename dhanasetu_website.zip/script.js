const menu=document.querySelector(".menu"),nav=document.querySelector(".nav nav");
menu.addEventListener("click",()=>nav.classList.toggle("open"));
document.querySelectorAll(".nav a").forEach(a=>a.addEventListener("click",()=>nav.classList.remove("open")));

const target=new Date("2026-09-21T09:00:00+05:30").getTime();
const el=document.getElementById("countdown");
function tick(){
  const diff=target-Date.now();
  if(diff<=0){el.innerHTML="<div>DHANASETU IS LIVE! 🎉</div>";return;}
  const d=Math.floor(diff/86400000),h=Math.floor(diff/3600000)%24,m=Math.floor(diff/60000)%60,s=Math.floor(diff/1000)%60;
  el.innerHTML=`<div>${d}<span>DAYS</span></div><div>${h}<span>HOURS</span></div><div>${m}<span>MINUTES</span></div><div>${s}<span>SECONDS</span></div>`;
}
tick();setInterval(tick,1000);
